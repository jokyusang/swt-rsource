package kr.namoosori.addressbook.service.facade;

import java.util.List;

import kr.namoosori.addressbook.domain.Address;

public interface AddressBookService {
	
	/** 주소 목록 조회 */
	List<Address> getAddressList();
	
	Address getAddress(int seqNo);
	
	List<Address> findAddressByName(String name);
	
	/** 주소 추가 */
	void saveNewAddress(Address address);
	
	/** 주소 수정 */
	void modifyAddress(Address address);
	
	/** 주소 삭제 */
	void removeAddress(int seqNo);

}
