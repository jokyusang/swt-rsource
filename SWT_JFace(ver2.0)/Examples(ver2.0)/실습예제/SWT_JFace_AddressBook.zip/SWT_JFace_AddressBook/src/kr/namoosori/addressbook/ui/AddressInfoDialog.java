package kr.namoosori.addressbook.ui;

import kr.namoosori.addressbook.domain.Address;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

public class AddressInfoDialog extends TitleAreaDialog {
	private Text nameText;
	private Text phoneText;
	private Text addressText;

	private Address address;
	private boolean isNewMode;
	
	/**
	 * Create the dialog.
	 * @param shell
	 */
	public AddressInfoDialog(Shell shell) {
		super(shell);
		isNewMode = true;
	}
	
	/**
	 * Create the dialog.
	 * @param shell
	 */
	public AddressInfoDialog(Shell shell, Address address) {
		super(shell);
		this.address = address;
		isNewMode = false;
	}

	/**
	 * Create contents of the dialog.
	 * @param parent
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		//
		if (isNewMode) {
			setTitle("주소 등록");
			setMessage("새로운 주소를 추가합니다.");
		} else {
			setTitle("주소 수정");
			setMessage("기존 주소를 수정합니다.");
		}
		
		Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);
		container.setLayout(new GridLayout(2, false));
		GridData gd_container = new GridData(GridData.FILL_BOTH);
		gd_container.heightHint = 99;
		container.setLayoutData(gd_container);
		
		Label nameLabel = new Label(container, SWT.NONE);
		nameLabel.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		nameLabel.setText("\uC774\uB984 :");
		
		nameText = new Text(container, SWT.BORDER);
		nameText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		Label phoneLabel = new Label(container, SWT.NONE);
		phoneLabel.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		phoneLabel.setText("\uC804\uD654\uBC88\uD638 :");
		
		phoneText = new Text(container, SWT.BORDER);
		phoneText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		Label addressLabel = new Label(container, SWT.NONE);
		addressLabel.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		addressLabel.setText("\uC8FC\uC18C :");
		
		addressText = new Text(container, SWT.BORDER);
		addressText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		if (address != null) {
			nameText.setText(address.getName());
			phoneText.setText(address.getPhone());
			addressText.setText(address.getAddress());
		}
		
		return area;
	}
	
	@Override
	protected void okPressed() {
		// 
		if (address == null) {
			address = new Address();
		}
		address.setName(nameText.getText());
		address.setPhone(phoneText.getText());
		address.setAddress(addressText.getText());
		
		super.okPressed();
	}

	public Address getAddress() {
		//
		return address;
	}
	
	/**
	 * Create contents of the button bar.
	 * @param parent
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		
		if (isNewMode) {
			createButton(parent, IDialogConstants.OK_ID, "등록", true);
			createButton(parent, IDialogConstants.CANCEL_ID, "취소", false);
		} else {
			createButton(parent, IDialogConstants.OK_ID, "저장", true);
			createButton(parent, IDialogConstants.CANCEL_ID, "취소", false);
		}
	}

	/**
	 * Return the initial size of the dialog.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(450, 300);
	}

}
