package kr.namoosori.addressbook.repository;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import kr.namoosori.addressbook.domain.AddressBook;

public class AddressBookRepository {
	
	private static final String DATA_FILE_NAME = "AddressBook.dat";

	//--------------------------------------------------------
	private static AddressBookRepository instance = new AddressBookRepository();
	
	public static AddressBookRepository getInstance() {
		//
		return instance;
	}
	
	//--------------------------------------------------------
	
	private AddressBookRepository() {
		//
	}
	
	public AddressBook getAddressBook() {
		//
		AddressBook addressBook = loadData();
		if (addressBook == null) {
			addressBook = new AddressBook();
		}
		
		return addressBook;
	}
	
	public void saveAddressBook(AddressBook addressBook) {
		//
		OutputStream os = null;
		ObjectOutputStream oos = null; 
		try {
			os = new FileOutputStream(DATA_FILE_NAME);
			oos = new ObjectOutputStream(os);
			oos.writeObject(addressBook);
			
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (oos != null) oos.close();
				if (os  != null) os.close();
			} catch (IOException e) {}
		}
		
	}

	private AddressBook loadData() {
		// 
		File dataFile = new File(DATA_FILE_NAME);
		if (!dataFile.exists()) {
			return null;
		}
		InputStream is = null;
		ObjectInputStream ois = null;
		AddressBook addressBook = null;
		try {
			is = new FileInputStream(DATA_FILE_NAME);
			ois = new ObjectInputStream(is);
			addressBook =  (AddressBook) ois.readObject();
			
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				if (ois != null) ois.close();
				if (is  != null) is.close();
			} catch (IOException e) {}
		}
		return addressBook;
	}
}
