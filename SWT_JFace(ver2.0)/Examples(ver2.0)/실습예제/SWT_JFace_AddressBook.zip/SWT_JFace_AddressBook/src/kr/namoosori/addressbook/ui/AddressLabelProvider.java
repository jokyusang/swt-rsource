package kr.namoosori.addressbook.ui;

import kr.namoosori.addressbook.domain.Address;

import org.eclipse.jface.viewers.IBaseLabelProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

public class AddressLabelProvider extends LabelProvider implements
		IBaseLabelProvider, ITableLabelProvider {

	@Override
	public Image getColumnImage(Object arg0, int arg1) {
		//
		return null;
	}

	@Override
	public String getColumnText(Object element, int columnIndex) {
		// 
		Address address = (Address) element;
		
		switch (columnIndex) {
		case 0:
			return String.valueOf(address.getSeqNo());
		case 1:
			return address.getName();
		case 2:
			return address.getPhone();
		case 3:
			return address.getAddress();
		default:
			return "Unknown column.";
		}
	}

}
