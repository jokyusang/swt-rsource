package kr.namoosori.addressbook.ui;

import java.util.List;

import kr.namoosori.addressbook.domain.Address;
import kr.namoosori.addressbook.service.facade.AddressBookService;
import kr.namoosori.addressbook.service.factory.AddressBookServiceFactory;

import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.StatusLineManager;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

public class AddressBookWindow extends ApplicationWindow {
	private Table table;
	private AddressBookService addressService;
	private Composite editButtonArea;
	private Address selectedAddress;
	
	/**
	 * Create the application window.
	 */
	public AddressBookWindow() {
		super(null);
		createActions();
		addToolBar(SWT.FLAT | SWT.WRAP);
		addMenuBar();
		addStatusLine();
		
		addressService = AddressBookServiceFactory.getInstance().getAddressBookService();
	}

	/**
	 * Create contents of the application window.
	 * @param parent
	 */
	@Override
	protected Control createContents(Composite parent) {
		final Composite container = new Composite(parent, SWT.NONE);
		container.setLayout(new GridLayout(1, false));
		
		final TableViewer tableViewer = new TableViewer(container, SWT.BORDER | SWT.FULL_SELECTION);
		table = tableViewer.getTable();
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		GridData gd_table = new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1);
		gd_table.heightHint = 119;
		table.setLayoutData(gd_table);
		{
			Composite composite = new Composite(container, SWT.NONE);
			GridData gd_composite = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
			gd_composite.widthHint = 424;
			composite.setLayoutData(gd_composite);
			composite.setLayout(new GridLayout(2, false));
			{
				Button addButton = new Button(composite, SWT.NONE);
				GridData gd_addButton = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
				gd_addButton.widthHint = 78;
				addButton.setLayoutData(gd_addButton);
				addButton.addSelectionListener(new SelectionAdapter() {
					@Override
					public void widgetSelected(SelectionEvent e) {
						//
						AddressInfoDialog dialog = new AddressInfoDialog(container.getShell());
						if (dialog.open() == Window.OK) {
							Address address = dialog.getAddress();
							addressService.saveNewAddress(address);
							
							List<Address> addressList = addressService.getAddressList();
							tableViewer.setInput(addressList.toArray());
						}
					}
				});
				addButton.setText("\uCD94\uAC00");
			}
			editButtonArea = new Composite(composite, SWT.NONE);
			editButtonArea.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, true, false, 1, 1));
			Button btnDel = new Button(editButtonArea, SWT.NONE);
			btnDel.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					//
					if (selectedAddress != null) {
						addressService.removeAddress(selectedAddress.getSeqNo());
						tableViewer.setInput(addressService.getAddressList().toArray());
						tableViewer.refresh();
						
						selectedAddress = null;
					}
				}
			});
			btnDel.setBounds(0, 0, 76, 25);
			btnDel.setText("\uC0AD\uC81C");
			Button btnModify = new Button(editButtonArea, SWT.NONE);
			btnModify.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					//
					if (selectedAddress != null) {
						AddressInfoDialog dialog = new AddressInfoDialog(container.getShell(), selectedAddress);
						if (dialog.open() == Window.OK) {
							selectedAddress = dialog.getAddress();
						}
						
						addressService.modifyAddress(selectedAddress);
						tableViewer.setInput(addressService.getAddressList().toArray());
					}
				}
			});
			btnModify.setBounds(82, 0, 76, 25);
			btnModify.setText("\uC218\uC815");
			editButtonArea.setVisible(false);
		}
		
		String[] columnNames = new String[] {"SeqNo", "Name", "Phone", "Address"};
		int[] columnWidths = new int[] {50, 80, 130, 160};
		
		for (int i = 0; i < 4; i++) {
			TableViewerColumn tableviewerColumn = new TableViewerColumn(tableViewer, SWT.NONE);
			TableColumn column = tableviewerColumn.getColumn();
			column.setText(columnNames[i]);
			column.setWidth(columnWidths[i]);
		}
		
		tableViewer.setContentProvider(new ArrayContentProvider());
		tableViewer.setLabelProvider(new AddressLabelProvider());
		
		tableViewer.addSelectionChangedListener(new ISelectionChangedListener() {
			
			@Override
			public void selectionChanged(SelectionChangedEvent event) {
				// 
				IStructuredSelection selection = (IStructuredSelection) event.getSelection();
				if (selection.getFirstElement() instanceof Address) {
					selectedAddress = (Address) selection.getFirstElement();
					editButtonArea.setVisible(true);
				} else {
					editButtonArea.setVisible(false);
				}
				
			}
		});
		
		List<Address> addresses = addressService.getAddressList();
		tableViewer.setInput(addresses.toArray());
		return container;
	}

	/**
	 * Create the actions.
	 */
	private void createActions() {
		// Create the actions
	}

	/**
	 * Create the menu manager.
	 * @return the menu manager
	 */
	@Override
	protected MenuManager createMenuManager() {
		MenuManager menuManager = new MenuManager("menu");
		return menuManager;
	}

	/**
	 * Create the toolbar manager.
	 * @return the toolbar manager
	 */
	@Override
	protected ToolBarManager createToolBarManager(int style) {
		ToolBarManager toolBarManager = new ToolBarManager(style);
		return toolBarManager;
	}

	/**
	 * Create the status line manager.
	 * @return the status line manager
	 */
	@Override
	protected StatusLineManager createStatusLineManager() {
		StatusLineManager statusLineManager = new StatusLineManager();
		return statusLineManager;
	}

	/**
	 * Configure the shell.
	 * @param newShell
	 */
	@Override
	protected void configureShell(Shell newShell) {
		super.configureShell(newShell);
		newShell.setText("Namoosori AddressBook");
	}

	/**
	 * Return the initial size of the window.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(450, 300);
	}
}
