package kr.namoosori.addressbook.domain;

import java.io.Serializable;

public class Address implements Serializable {

	private static final long serialVersionUID = -1095864551656691172L;

	private int seqNo;
	private String name;
	private String phone;
	private String address;

	public int getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(int seqNo) {
		this.seqNo = seqNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
}
