package kr.namoosori.addressbook.service.factory;

import kr.namoosori.addressbook.service.facade.AddressBookService;
import kr.namoosori.addressbook.service.logic.AddressBookServiceLogic;

public class AddressBookServiceFactory {
	
	private static final AddressBookServiceFactory instance = new AddressBookServiceFactory();
	
	public static AddressBookServiceFactory getInstance() {
		//
		return instance;
	}
	
	public AddressBookService getAddressBookService() {
		//
		return new AddressBookServiceLogic();
	}
}
