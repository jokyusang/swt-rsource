package kr.namoosori.addressbook.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AddressBook implements Serializable {

	private static final long serialVersionUID = 2614355783157092639L;

	private int nextSequence;
	private List<Address> addresses;
	
	public AddressBook() {
		//
		this.addresses = new ArrayList<>();
	}
	
	
	public void addAddress(Address address) {
		//
		this.addresses.add(address);
	}

	public List<Address> getAddressList() {
		// 
		return addresses;
	}


	public Address findAddress(int seqNo) {
		// 
		for (Address address : addresses) {
			if (address.getSeqNo() == seqNo) {
				return address;
			}
		}
		return null;
	}


	public void removeAddress(int seqNo) {
		//
		Address removed = null;
		for (Address address : addresses) {
			if (address.getSeqNo() == seqNo) {
				removed = address;
			}
		}
		
		if (removed != null) {
			addresses.remove(removed);
		}
	}

	public List<Address> findAddressByName(String name) {
		// 
		List<Address> founds = new ArrayList<>();
		for (Address address : addresses) {
			if (address.getName().equals(name)) {
				founds.add(address);
			}
		}
		return founds;
	}
	
	public int nextSequence() {
		return nextSequence++;
	}

}
