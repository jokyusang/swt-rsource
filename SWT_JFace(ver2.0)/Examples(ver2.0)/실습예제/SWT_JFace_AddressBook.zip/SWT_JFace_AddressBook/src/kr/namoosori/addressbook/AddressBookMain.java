package kr.namoosori.addressbook;

import kr.namoosori.addressbook.ui.AddressBookWindow;

import org.eclipse.swt.widgets.Display;

public class AddressBookMain {
	
	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String args[]) {
		try {
			AddressBookWindow window = new AddressBookWindow();
			window.setBlockOnOpen(true);
			window.open();
			Display.getCurrent().dispose();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
