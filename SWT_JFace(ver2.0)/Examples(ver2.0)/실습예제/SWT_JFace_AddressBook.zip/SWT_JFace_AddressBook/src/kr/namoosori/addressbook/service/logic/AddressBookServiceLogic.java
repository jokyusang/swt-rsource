package kr.namoosori.addressbook.service.logic;

import java.util.ArrayList;
import java.util.List;

import kr.namoosori.addressbook.domain.Address;
import kr.namoosori.addressbook.domain.AddressBook;
import kr.namoosori.addressbook.repository.AddressBookRepository;
import kr.namoosori.addressbook.service.facade.AddressBookService;

public class AddressBookServiceLogic implements AddressBookService {

	private AddressBookRepository repo;
	
	public AddressBookServiceLogic() {
		//
		repo = AddressBookRepository.getInstance();
	}
	
	@Override
	public List<Address> getAddressList() {
		// 
		return repo.getAddressBook().getAddressList();
	}

	@Override
	public Address getAddress(int seqNo) {
		// 
		return repo.getAddressBook().findAddress(seqNo);
	}

	@Override
	public List<Address> findAddressByName(String name) {
		// 
		AddressBook addressBook = repo.getAddressBook();
		List<Address> founds = new ArrayList<>();
		for (Address address : addressBook.getAddressList()) {
			if (address.getName().equals(name)) {
				founds.add(address);
			}
		}
		return founds;
	}

	@Override
	public void saveNewAddress(Address address) {
		// 
		AddressBook addressBook = repo.getAddressBook();
		
		int newSeqNo = addressBook.nextSequence();
		address.setSeqNo(newSeqNo);
		addressBook.addAddress(address);

		repo.saveAddressBook(addressBook);
	}

	@Override
	public void modifyAddress(Address address) {
		//
		AddressBook addressBook = repo.getAddressBook();
		Address previous = addressBook.findAddress(address.getSeqNo());
		
		previous.setName(address.getName());
		previous.setPhone(address.getPhone());
		previous.setAddress(address.getAddress());
		
		repo.saveAddressBook(addressBook);
	}

	@Override
	public void removeAddress(int seqNo) {
		//
		AddressBook addressBook = repo.getAddressBook();
		addressBook.removeAddress(seqNo);
		
		repo.saveAddressBook(addressBook);
	}

}
