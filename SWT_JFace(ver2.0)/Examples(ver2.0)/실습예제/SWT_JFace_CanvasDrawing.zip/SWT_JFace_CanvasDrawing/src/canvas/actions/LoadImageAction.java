package canvas.actions;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.ImageLoader;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;

import canvas.CanvasHolder;

public class LoadImageAction extends Action {
	//
	private CanvasHolder canvasHolder;
	
	public LoadImageAction(CanvasHolder canvasHolder) {
		//
		super("&Load Image@Ctrl+O");
		this.canvasHolder = canvasHolder;
		
		setImageDescriptor(
			ImageDescriptor.createFromFile(this.getClass(), "load.ico"));

	}

	@Override
	public void run() {
		//
		Shell shell = Display.getCurrent().getActiveShell();
		String[] filterNames = new String[] {
			"PNG (*.png)", "BMP (*.bmp)", "JPG (*.jpg)"
		};
		String[] filterExts = new String[] {"*.png", "*.bmp", "*.jpg"};
		
		FileDialog fileDialog = new FileDialog(shell, SWT.OPEN);
		fileDialog.setFilterNames(filterNames);
		fileDialog.setFilterExtensions(filterExts);
		String fileName = fileDialog.open();
		
		if (fileName != null) {
			//
			ImageLoader imageLoader = new ImageLoader();
			ImageData[] imageData = imageLoader.load(fileName);
			Image image = new Image(Display.getCurrent(), imageData[0]);
			
			GC gc = new GC(canvasHolder.canvas);
			gc.drawImage(image, 0, 0);
			
			gc.dispose();
			image.dispose();
		}
	}

}
