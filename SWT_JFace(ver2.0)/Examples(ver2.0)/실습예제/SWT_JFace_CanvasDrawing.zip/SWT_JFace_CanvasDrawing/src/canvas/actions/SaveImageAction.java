package canvas.actions;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.ImageLoader;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;

import canvas.CanvasHolder;

public class SaveImageAction extends Action {
	//
	private CanvasHolder canvasHolder;
	
	public SaveImageAction(CanvasHolder canvasHolder) {
		super("&Save Image@Ctrl+S");
		this.canvasHolder = canvasHolder;
		
		setImageDescriptor(
				ImageDescriptor.createFromFile(this.getClass(), "save.ico"));
	}

	@Override
	public void run() {
		//
		Shell shell = Display.getCurrent().getActiveShell();
		String[] filterNames = new String[] {
			"PNG (*.png)", "BMP (*.bmp)", "JPG (*.jpg)"
		};
		String[] filterExts = new String[] {"*.png", "*.bmp", "*.jpg"};
		int[] imageExts = new int[]{
			SWT.IMAGE_PNG, SWT.IMAGE_BMP, SWT.IMAGE_JPEG
		};
		
		FileDialog fileDialog = new FileDialog(shell, SWT.SAVE);
		fileDialog.setFilterNames(filterNames);
		fileDialog.setFilterExtensions(filterExts);
		String fileName = fileDialog.open();
		
		if (fileName != null) {
			Canvas canvas = canvasHolder.canvas;
			GC gc = new GC(canvas);
			Image image = new Image(
					canvas.getDisplay(), canvas.getSize().x, canvas.getSize().y);
			
			gc.copyArea(image, 0, 0);
			
			ImageLoader loader = new ImageLoader();
			loader.data = new ImageData[] {image.getImageData()};
			loader.save(fileName, imageExts[fileDialog.getFilterIndex()]);
			
			image.dispose();
			gc.dispose();
		}
	}
}
