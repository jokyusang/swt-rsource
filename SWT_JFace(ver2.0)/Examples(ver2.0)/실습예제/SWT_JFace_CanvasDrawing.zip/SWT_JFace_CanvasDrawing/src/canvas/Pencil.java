package canvas;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseMoveListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Canvas;

public class Pencil extends MouseAdapter implements MouseMoveListener {
	//
	private boolean pressed;
	private int prevX;
	private int prevY;
	private Canvas canvas;
	private List<Point> points;

	public Pencil(Canvas canvas) {
		//
		points = new ArrayList<>();
		this.canvas = canvas;
		canvas.addMouseListener(this);
		canvas.addMouseMoveListener(this);
		
		canvas.addPaintListener(new PaintListener() {
			@Override
			public void paintControl(PaintEvent event) {
				// 
				Iterator<Point> iter = points.iterator();
				while (iter.hasNext()) {
					Point start = iter.next();
					Point end = iter.next();
					
					event.gc.drawLine(
						start.x, start.y, end.x, end.y);
				}
			}
		});
	}
	
	public boolean isPressed() {
		return pressed;
	}

	public void setPressed(boolean pressed) {
		this.pressed = pressed;
	}

	public int getPrevX() {
		return prevX;
	}

	public void setPrevX(int prevX) {
		this.prevX = prevX;
	}

	public int getPrevY() {
		return prevY;
	}

	public void setPrevY(int prevY) {
		this.prevY = prevY;
	}
	
	//-------------------------------------------------------------
	
	@Override
	public void mouseMove(MouseEvent event) {
		// 
		if (this.isPressed()) {
			GC gc = new GC(canvas);
			gc.drawLine(
					this.getPrevX(), this.getPrevY(), 
					event.x, event.y);
			
			points.add(new Point(this.getPrevX(), this.getPrevY()));
			points.add(new Point(event.x, event.y));
			
			gc.dispose();
		}
		this.setPrevX(event.x);
		this.setPrevY(event.y);
	}
	
	@Override
	public void mouseDown(MouseEvent e) {
		// 
		this.setPressed(true);
	}

	@Override
	public void mouseUp(MouseEvent e) {
		// 
		this.setPressed(false);
	}
}
