package canvas;

import org.eclipse.swt.widgets.Canvas;

public class CanvasHolder {
	
	public Canvas canvas;

	public static void main(String[] args) {
	}
}
