package canvas;

import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.StatusLineManager;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseMoveListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;

import canvas.actions.LoadImageAction;
import canvas.actions.SaveImageAction;

public class JFaceCanvasMain extends ApplicationWindow {

	private CanvasHolder canvasHolder = new CanvasHolder();
	private StatusLineManager statusLineManager;
	
	public JFaceCanvasMain() {
		super(null);
		addMenuBar();
		addToolBar(SWT.FLAT | SWT.WRAP);
		addStatusLine();
	}

	@Override
	protected MenuManager createMenuManager() {
		// 
		MenuManager main = new MenuManager(null);
		MenuManager sub = new MenuManager("&File");
		main.add(sub);
		sub.add(new SaveImageAction(canvasHolder));
		sub.add(new LoadImageAction(canvasHolder));
		return main;
	}
	
	@Override
	protected StatusLineManager createStatusLineManager() {
		// 
		statusLineManager = new StatusLineManager();
		return statusLineManager;
	}

	@Override
	protected ToolBarManager createToolBarManager(int style) {
		// 
		ToolBarManager manager = new ToolBarManager(style);
		manager.add(new SaveImageAction(canvasHolder));
		manager.add(new LoadImageAction(canvasHolder));
		
		return manager;
	}

	@Override
	protected Control createContents(Composite parent) {
		// 
		parent.setSize(600, 600);
		Display display = Display.getCurrent();
		//Display display = parent.getDisplay();
		Color white = new Color(display, 255, 255, 255);
		
		Canvas canvas = new Canvas(parent, SWT.BORDER);
		canvasHolder.canvas = canvas;
		canvas.setBackground(white);
		
		// create pencil
		new Pencil(canvas);
		
		// 상태표시줄에 마우스 좌표 출력
		canvas.addMouseMoveListener(new MouseMoveListener() {
			
			@Override
			public void mouseMove(MouseEvent event) {
				//
				String message = event.x + ", " + event.y + "px";
				statusLineManager.setMessage(message);
			}
		});
		
		return parent;
	}

	public static void main(String[] args) {
		//
		JFaceCanvasMain main = new JFaceCanvasMain();
		main.setBlockOnOpen(true);
		main.open();
		
		Display.getCurrent().dispose();
	}
}
