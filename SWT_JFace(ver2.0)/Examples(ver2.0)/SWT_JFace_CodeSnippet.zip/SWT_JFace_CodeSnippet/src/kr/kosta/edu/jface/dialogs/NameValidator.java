package kr.kosta.edu.jface.dialogs;

import org.eclipse.jface.dialogs.IInputValidator;

public class NameValidator implements IInputValidator {

	@Override
	public String isValid(String value) {
		// 
		int length = value.length();
		
		if (length == 0) {
			return "이름을 입력하세요.";
		} else if (length > 50) {
			return "이름은 50 글자 내에서 입력하세요.";
		}
		return null;
	}

}
