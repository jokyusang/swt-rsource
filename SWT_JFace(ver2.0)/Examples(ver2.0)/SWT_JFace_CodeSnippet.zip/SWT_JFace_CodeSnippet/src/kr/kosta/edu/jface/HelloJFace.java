package kr.kosta.edu.jface;

import org.eclipse.jface.action.ActionContributionItem;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.StatusLineManager;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Text;

public class HelloJFace extends ApplicationWindow {

	private StatusLineManager statusLine = new StatusLineManager();
	private StatusAction statusAction = new StatusAction(statusLine);
	
	public HelloJFace() {
		super(null);
		
		addStatusLine();
		addMenuBar();
		addToolBar(SWT.FLAT | SWT.WRAP);
	}

	@Override
	protected Control createContents(Composite parent) {
		// 
		getShell().setText("JFace 예제");
		parent.setSize(300, 200);
		Text helloText = new Text(parent, SWT.CENTER);
		helloText.setText("Hello SWT and JFace");
		
		return parent;
	}
	
	@Override
	protected MenuManager createMenuManager() {
		// 
		MenuManager main = new MenuManager(null);
		MenuManager sub = new MenuManager("&Menu");
		main.add(sub);
		sub.add(statusAction);
		
		return main;
	}

	@Override
	protected StatusLineManager createStatusLineManager() {
		// 
		return statusLine;
	}
	
	@Override
	protected ToolBarManager createToolBarManager(int style) {
		// 
		ToolBarManager toolbar = new ToolBarManager(style);
		// 액션추가 방법 #1
		//toolbar.add(this.statusAction);

		// 액션추가 방법 #2
		ActionContributionItem item = new ActionContributionItem(statusAction);
		item.setMode(ActionContributionItem.MODE_FORCE_TEXT);
		toolbar.add(item);
		
		return toolbar;
	}

	public static void main(String[] args) {
		//
		HelloJFace win = new HelloJFace();
		win.setBlockOnOpen(true);
		win.open();
		
		Display.getCurrent().dispose();
	}
}
