package kr.kosta.edu.jface.dialogs;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class LoginDialog extends Dialog {

	protected LoginDialog(Shell parentShell) {
		super(parentShell);
	}
	
	@Override
	protected void configureShell(Shell newShell) {
		// 
		super.configureShell(newShell);
		newShell.setText("Login");
	}

	@Override
	protected Control createDialogArea(Composite parent) {
		// 
		Composite composite = (Composite) super.createDialogArea(parent);
		composite.setLayout(new GridLayout(2, false));
		
		Label idLabel = new Label(composite, SWT.NONE);
		idLabel.setText("ID :");
		
		GridData inputTextData = new GridData(SWT.FILL);
		inputTextData.grabExcessHorizontalSpace = true;
		inputTextData.horizontalAlignment = SWT.FILL;
		inputTextData.heightHint = 15;
		
		Text idText = new Text(composite, SWT.BORDER);
		idText.setLayoutData(inputTextData);
		
		Label passwordLabel = new Label(composite, SWT.NONE);
		
		passwordLabel.setText("Password :");
		Text passwordText = new Text(composite, SWT.BORDER);
		passwordText.setLayoutData(inputTextData);
		
		return composite;
	}
	
	
	

}
