package kr.kosta.edu.swt.layout;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class HelloSWTGridLayout {
	//
	public static void main(String[] args) {
		//
		Display display = new Display();
		
		Shell shell = new Shell(display);
		shell.setText("Hello SWT");
		shell.setBounds(100, 100, 400, 160);
		
		//----------------------------------------------------------------------
		shell.setLayout(new GridLayout(4, false));
		
		Button button1 = new Button(shell, SWT.NONE);
		button1.setText("Button1");
		GridData gd1 = new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1 );
		button1.setLayoutData(gd1);
		
		Button button2 = new Button(shell, SWT.NONE);
		button2.setText("Button2");
		GridData gd2 = new GridData(SWT.FILL, SWT.FILL, false, false, 1, 1);
		button2.setLayoutData(gd2);
		
		Button button3 = new Button(shell, SWT.NONE);
		button3.setText("Button3");
		GridData gd3 = new GridData(SWT.FILL, SWT.FILL, false, false, 1, 1);
		button3.setLayoutData(gd3);
		
		Button button4 = new Button(shell, SWT.NONE);
		button4.setText("Button4");
		GridData gd4 = new GridData(SWT.FILL, SWT.FILL, false, false, 1, 1);
		button4.setLayoutData(gd4);
		
		Button button5 = new Button(shell, SWT.NONE);
		button5.setText("Button5");
		GridData gd5 = new GridData(SWT.FILL, SWT.FILL, false, true, 1, 1);
		button5.setLayoutData(gd5);
		
		Button button6 = new Button(shell, SWT.NONE);
		button6.setText("Button6");
		GridData gd6 = new GridData(SWT.FILL, SWT.FILL, false, false, 3, 1);
		button6.setLayoutData(gd6);
		
		
		//----------------------------------------------------------------------
		shell.open();
		
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
 		}
		//----------------------------------------------------------------------
		
		display.dispose();
	}
}
