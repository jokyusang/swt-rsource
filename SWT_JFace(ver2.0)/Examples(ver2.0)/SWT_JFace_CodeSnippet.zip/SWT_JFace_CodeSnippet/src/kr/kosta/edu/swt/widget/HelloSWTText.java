package kr.kosta.edu.swt.widget;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class HelloSWTText {
	
	public static void main(String[] args) {
		//
		Display display = new Display();
		
		Shell shell = new Shell(display);
		shell.setText("Hello SWT");
		shell.setBounds(100, 100, 200, 80);
		shell.setLayout(new FillLayout());
		
		//----------------------------------------------------------------------
		
		final Text text = new Text(shell, SWT.MULTI | SWT.WRAP);
		text.addVerifyListener(new VerifyListener() {
			
			@Override
			public void verifyText(VerifyEvent event) {
				// 
				if (event.text.length() == 0) {
					event.doit = true;
				} else if (Character.isDigit(event.text.charAt(0))){
					event.doit = true;
				} else if (event.text.charAt(0) == SWT.CR) {
					event.doit = true;
				} else {
					event.doit = false;
				}
			}
		});
		
		//----------------------------------------------------------------------
		shell.open();
		
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
 		}
		//----------------------------------------------------------------------
		
		display.dispose();
	}

}
