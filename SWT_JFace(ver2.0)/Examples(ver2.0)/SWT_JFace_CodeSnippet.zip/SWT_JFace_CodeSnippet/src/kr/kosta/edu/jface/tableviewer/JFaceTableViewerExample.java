package kr.kosta.edu.jface.tableviewer;

import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

public class JFaceTableViewerExample {
	//
	public static void main(String[] args) {
		// 
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setText("JFace TableViewer example");
		shell.setBounds(100, 100, 325, 200);
		shell.setLayout(new FillLayout());
		//-------------------------------------------------------------
		
		TableViewer tableViewer = 
				new TableViewer(shell, SWT.SINGLE | SWT.FULL_SELECTION);
		
		Table table = tableViewer.getTable();
		table.setHeaderVisible(true); // 테이블의 헤더를 보여줌
		table.setLinesVisible(true);  // 테이블의 구분선을 보여줌
		
		String[] columnNames = new String[] {"First Name", "Last Name", "Age", "NumChildren"};

		int[] columnWidths = new int[] {90, 90, 35, 90};
		int[] columnAlignments = new int[] {SWT.LEFT, SWT.LEFT, SWT.CENTER, SWT.CENTER};
		
		int columnLength = columnNames.length;
		for (int i = 0; i < columnLength; i++) {
			TableColumn tableColumn = new TableColumn(table, columnAlignments[i]);
			tableColumn.setText(columnNames[i]);
			tableColumn.setWidth(columnWidths[i]);
		}

		tableViewer.setContentProvider(new ArrayContentProvider());
		tableViewer.setLabelProvider(new PersonTableLabelProvider());
		tableViewer.setInput(Person.example());

		// add sorter
		new TableColumnsSelectionListener(new TableSorter(), tableViewer);
		
		// event listener 
		tableViewer.addSelectionChangedListener(new ISelectionChangedListener() {
			
			@Override
			public void selectionChanged(SelectionChangedEvent event) {
				// 
				ISelection sel = event.getSelection();
				IStructuredSelection stSelection = (IStructuredSelection) sel;
				Object data = stSelection.getFirstElement();
				
				if (data instanceof Person) {
					Person person = (Person) data;
					System.out.println("[Selection!] " + person.firstName);
				}
			}
		});
		
		tableViewer.addDoubleClickListener(new IDoubleClickListener() {
			
			@Override
			public void doubleClick(DoubleClickEvent event) {
				//
				ISelection sel = event.getSelection();
				IStructuredSelection stSelection = (IStructuredSelection) sel;
				Object data = stSelection.getFirstElement();
				
				if (data instanceof Person) {
					Person person = (Person) data;
					System.out.println("[Double click!] " + person.firstName);
				}
			}
		});
		
		shell.open();
		//-------------------------------------------------------------
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		display.dispose();
	}

}
