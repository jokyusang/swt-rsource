package kr.kosta.edu.jface.dialogs;

import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class DialogTest extends ApplicationWindow {

	public DialogTest() {
		super(null);
	}

	@Override
	protected Control createContents(Composite parent) {
		// 
		parent.setSize(400, 400);
		parent.setLayout(new GridLayout());
		
		Button errorBtn = new Button(parent, SWT.NONE);
		errorBtn.setText("에러메시지");
		errorBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Shell shell = getShell();
				MessageDialog.openError(shell, "게임오버", "게임실패");
			}
		});
		
		Button confirmBtn = new Button(parent, SWT.NONE);
		confirmBtn.setText("확인메시지");
		confirmBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Shell shell = getShell();
				MessageDialog.openConfirm(shell, "확인", "계속할래?");
			}
		});
		
		Button inputBtn = new Button(parent, SWT.NONE);
		inputBtn.setText("입력메시지");
		inputBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Shell shell = getShell();
				InputDialog dialog = new InputDialog(shell, 
						"게임성공", 
						"이름을 입력하세요.", 
						"", 
						null);
				if (dialog.open() == Window.OK) {
					String name = dialog.getValue();
					System.out.println(name);
				};
			}
		});
		
		return parent;
	}
	
	public static void main(String[] args) {
		//
		DialogTest test = new DialogTest();
		test.setBlockOnOpen(true);
		test.open();
		
		Display.getCurrent().dispose();
	}
}
 