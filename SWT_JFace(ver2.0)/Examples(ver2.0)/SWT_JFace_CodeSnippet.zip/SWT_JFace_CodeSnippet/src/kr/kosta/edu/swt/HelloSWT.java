package kr.kosta.edu.swt;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

public class HelloSWT {

	public static void main(String[] args) {
		//
		Display display = new Display();
		
		Shell shell = new Shell(display);
		shell.setText("Hello SWT");
		shell.setBounds(100, 100, 200, 80);
		
		shell.setLayout(new FillLayout());
		
		Label label = new Label(shell, SWT.CENTER);
		label.setText("Hello SWT !");
		
		Color red = new Color(display, 255, 0, 0);
		label.setForeground(red);
		shell.open();
		
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		} 
		
		red.dispose();
		display.dispose();
	}
}
