package kr.kosta.edu.swt.layout;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class GridLayoutExample_Join {
	
	public static void main(String[] args) {
		//
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setSize(400, 400);
		//----------------------------------------------------------------------

		shell.setLayout(new GridLayout(2, false));

		// 이름
		Label labelName = new Label(shell, SWT.NONE);
		labelName.setText("이름 : ");
		
		Text textName = new Text(shell, SWT.SINGLE | SWT.BORDER);
		textName.setLayoutData(
				new GridData(GridData.FILL_HORIZONTAL));
		
		// 주소
		Label labelAddress = new Label(shell, SWT.NONE);
		labelAddress.setText("주소 : ");
		Text textAddress = new Text(shell, SWT.MULTI | SWT.BORDER);
		textAddress.setLayoutData(
				new GridData(GridData.FILL_HORIZONTAL));
		
		// 좋아하는 스포츠
		Label labelFavSports = new Label(shell, SWT.NONE);
		labelFavSports.setLayoutData(
				new GridData(SWT.FILL, SWT.FILL, false, false, 2, 1));
		labelFavSports.setText("좋아하는 스포츠 : ");
		
		List listFavSports = new List(shell, SWT.BORDER | SWT.MULTI);
		listFavSports.setLayoutData(
				new GridData(SWT.FILL, SWT.FILL, false, false, 2, 1));
		listFavSports.setItems(new String[] {"축구", "야구"});
		
		//----------------------------------------------------------------------
		shell.open();
		
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
 		}
		//----------------------------------------------------------------------
		
		display.dispose();
	}
}
