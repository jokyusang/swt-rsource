package kr.kosta.edu.jface.dialogs;

import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class DialogMain {
	//
	public static void main(String[] args) {
		//
		Display display = new Display();
		final Shell shell = new Shell(display);
		shell.setSize(400, 400);
		shell.setLayout(new GridLayout());
		
		//-----------------------------------------------
		
		Button btn1 = new Button(shell, SWT.NONE);
		btn1.setText("정보메시지");
		btn1.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				// 
				MessageDialog.openInformation(
						shell, 
						"정보메시지", 
						"이 메시지창은 정보메시지 입니다.");
			}
		});
		
		Button btn2 = new Button(shell, SWT.NONE);
		btn2.setText("에러메시지");
		btn2.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				// 
				MessageDialog.openError(
						shell, 
						"에러메시지", 
						"이 메시지창은 에러메시지 입니다.");
			}
			
		});
		
		Button btn3 = new Button(shell, SWT.NONE);
		btn3.setText("확인메시지");
		btn3.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				
				boolean ok = MessageDialog.openConfirm(shell, 
						"확인메시지", 
						"정말로 수행하시겠습니까?");
				System.out.println(ok);
			}
		});
		
		Button btn4 = new Button(shell, SWT.NONE);
		btn4.setText("입력메시지");
		btn4.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				//
				InputDialog dialog = new InputDialog(
					Display.getCurrent().getActiveShell(), 
					"입력메시지", 
					"이름을 입력하세요.", 
					"", 
					new NameValidator());
				
				if (dialog.open() == Window.OK) {
					String name = dialog.getValue();
					System.out.println(name + "님 안녕하세요.!");
				}
			}
		});
		
		Button btn5 = new Button(shell, SWT.NONE);
		btn5.setText("로그인 다이얼로그");
		btn5.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				// 
				LoginDialog dialog = new LoginDialog(shell);
				dialog.open();
			}
		});
		
		
		//-----------------------------------------------
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		display.dispose();
	}
}











