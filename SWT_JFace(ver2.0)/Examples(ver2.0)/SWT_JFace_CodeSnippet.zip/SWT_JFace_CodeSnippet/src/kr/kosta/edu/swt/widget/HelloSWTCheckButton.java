package kr.kosta.edu.swt.widget;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class HelloSWTCheckButton {
	
	public static void main(String[] args) {
		//
		Display display = new Display();
		
		Shell shell = new Shell(display);
		shell.setText("Hello SWT");
		shell.setBounds(100, 100, 200, 80);
		shell.setLayout(new FillLayout());
		
		//----------------------------------------------------------------------
		
		Button button1 = new Button(shell, SWT.RADIO); // or SWT.CHECK
		button1.setText("선택 1");
		
		Button button2 = new Button(shell, SWT.RADIO); // or SWT.CHECK
		button2.setText("선택 2");
		//----------------------------------------------------------------------
		shell.open();
		
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
 		}
		//----------------------------------------------------------------------
		
		display.dispose();
	}

}
