package kr.kosta.edu.swt.layout;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class SampleGrapExcess {

	public static void main(String[] args) {
		//
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout(2, false));
		
		//
		Label nameLabel = new Label(shell, SWT.NONE);
		nameLabel.setText("이름 : ");
		
		Text nameText = new Text(shell, SWT.BORDER);
		GridData nameData = new GridData();
		nameData.horizontalAlignment = SWT.FILL;
		nameData.grabExcessHorizontalSpace = true;
		nameData.widthHint = 150;
		nameText.setLayoutData(nameData);

		Label addressLabel = new Label(shell, SWT.NONE);
		GridData addressLabelData = new GridData();
		addressLabelData.verticalAlignment = SWT.TOP;
		addressLabel.setLayoutData(addressLabelData);
		addressLabel.setText("주소 : ");
		
		Text addressText = new Text(shell, SWT.BORDER | SWT.MULTI | SWT.WRAP);
		GridData addressData = new GridData();
		addressData.horizontalAlignment = SWT.FILL;
		addressData.verticalAlignment = SWT.FILL;
		addressData.grabExcessHorizontalSpace = true;
		addressData.grabExcessVerticalSpace = true;
		addressData.heightHint = 50;
		addressText.setLayoutData(addressData);
		
		Label sportsLabel = new Label(shell, SWT.NONE);
		GridData sportData = new GridData();
		sportData.horizontalSpan = 2;
		sportsLabel.setLayoutData(sportData);
		sportsLabel.setText("좋아하는 스포츠 : ");
		
		List sportsList = new List(shell, SWT.MULTI | SWT.BORDER);
		GridData listData = new GridData();
		listData.horizontalAlignment = SWT.FILL;
		listData.verticalAlignment = SWT.FILL;
		listData.grabExcessHorizontalSpace = true;
		listData.grabExcessVerticalSpace = true;
		listData.horizontalSpan = 2;
		listData.heightHint = 50;
		sportsList.setLayoutData(listData);
		sportsList.setItems(new String[] {"축구", "야구"});
		
		shell.pack();
		shell.open();
		
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		
		display.dispose();
	}
}
