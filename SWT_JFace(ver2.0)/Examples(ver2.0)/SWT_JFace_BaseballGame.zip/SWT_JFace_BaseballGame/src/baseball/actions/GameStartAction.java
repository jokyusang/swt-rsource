package baseball.actions;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import baseball.Dashboard;
import baseball.engine.GameEngine;
import baseball.rank.RankDataHandler;
import baseball.rank.RankDialog;

public class GameStartAction extends Action {

	private Dashboard dashboard;
	
	public GameStartAction(Dashboard dashboard) {
		//
		super("&Start Game");
		
		this.dashboard = dashboard;
	}
	
	@Override
	public void run() {
		// 
		GameEngine engine = new GameEngine(dashboard);
		engine.prepare(); // 게임준비
		
		long start = System.currentTimeMillis();
		int tryCount = engine.start(); // 게임시작
		
		if (tryCount > 0) {
			//
			long finish = System.currentTimeMillis();
			
			Shell shell = Display.getCurrent().getActiveShell();
			InputDialog dialog = new InputDialog(shell, 
					"게임성공", "축하합니다. 이름을 입력하세요", "", null);
			
			if (dialog.open() == Window.OK) {
				String playerName = dialog.getValue();
				int elapsedTime = (int) ((finish - start) / 1000);

				dashboard.addMessage("게임성공! 축하합니다.");

				RankDataHandler.saveLog(playerName, elapsedTime, tryCount);
				
				// 게임결과 다이얼로그 호출
				RankDialog resultDialog = new RankDialog(shell);
				resultDialog.open();
			}
		}
	}
}
