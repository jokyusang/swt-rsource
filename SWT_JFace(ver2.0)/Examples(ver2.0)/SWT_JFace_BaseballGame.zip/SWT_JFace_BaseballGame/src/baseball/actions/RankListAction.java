package baseball.actions;

import org.eclipse.jface.action.Action;
import org.eclipse.swt.widgets.Display;

import baseball.rank.RankDialog;

public class RankListAction extends Action {
	
	public RankListAction() {
		//
		super("&Show Result");
	}
	
	@Override
	public void run() {
		//
		RankDialog dialog = new RankDialog(
				Display.getCurrent().getActiveShell());
		dialog.open();
	}
}
