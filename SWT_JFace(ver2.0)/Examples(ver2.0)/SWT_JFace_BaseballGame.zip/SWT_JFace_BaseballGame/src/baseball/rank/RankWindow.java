package baseball.rank;

import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

public class RankWindow {
	
	public static void main(String[] args) {
		//
		Display display = new Display();
		Shell shell = new Shell(display);
		
		shell.setLayout(new GridLayout());
		shell.setSize(400, 400);
		
		//---------------------------------------------------------
		
		Label label = new Label(shell, SWT.NONE);
		label.setText("Game Result");
		
		TableViewer tableViewer = new TableViewer(shell);
		Table table = tableViewer.getTable();
		table.setLinesVisible(true);
		table.setHeaderVisible(true);

		String[] columnNames = new String[] {"Rank", "Name", "ElapsedTime", "TryCount"};
		int[] columnWidths = new int[] {70, 130, 80, 80};
		int[] columnAligns = new int[] {SWT.CENTER, SWT.LEFT, SWT.CENTER, SWT.CENTER};
		
		for (int i = 0; i < 4; i++) {
			TableColumn column = new TableColumn(table, columnAligns[i]);
			column.setWidth(columnWidths[i]);
			column.setText(columnNames[i]);
		}
		
		tableViewer.setContentProvider(new ArrayContentProvider());
		tableViewer.setLabelProvider(new RankLabelProvider());
		
		tableViewer.setInput(RankDataHandler.readRankList());
		
		//--------------------------------------------------------
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		display.dispose();
	}

}
