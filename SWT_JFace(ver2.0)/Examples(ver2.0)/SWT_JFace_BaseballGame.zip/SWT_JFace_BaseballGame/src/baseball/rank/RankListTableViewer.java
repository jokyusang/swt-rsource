package baseball.rank;

import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

public class RankListTableViewer extends TableViewer {

	public RankListTableViewer(Composite parent) {
		super(parent, SWT.SINGLE | SWT.FULL_SELECTION);
		init();
	}

	private void init() {
		// 
		Table table = getTable();
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		String[] columnNames = new String[] {"Rank", "Name", "ElapsedTime", "TryCount"};
		int[] columnWidths = new int[] {70, 130, 80, 80};
		int[] columnAligns = new int[] {SWT.CENTER, SWT.LEFT, SWT.CENTER, SWT.CENTER};
		
		for (int i = 0; i < 4; i++) {
			TableColumn column = new TableColumn(table, columnAligns[i]);
			column.setWidth(columnWidths[i]);
			column.setText(columnNames[i]);
		}
		
		setContentProvider(new ArrayContentProvider());
		setLabelProvider(new RankLabelProvider());
		
	}}
