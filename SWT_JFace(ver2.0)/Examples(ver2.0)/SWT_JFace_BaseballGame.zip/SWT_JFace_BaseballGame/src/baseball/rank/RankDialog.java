package baseball.rank;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

public class RankDialog extends Dialog {

	public RankDialog(Shell parent) {
		super(parent);
	}

	/**
	 * 대화창에서 버튼바 위에 있는 컨텐츠 영역을 생성하고 반환한다. 
	 * 하위 클래스는 일반적으로 상위 클래스 메소드를 호출한 다음에 반환된다.
	 * 컴포지트에 컨트롤을 추가한다.
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		//
		Display display = parent.getDisplay();
		parent.getShell().setText("Game Result");

		// font
		final Font font = new Font(display, "Times New Roman", 15, SWT.NONE);
		
		parent.setLayout(new GridLayout(1,  false));
		
		// title
		Label title = new Label(parent, SWT.NONE);
		title.setText("Game Result");
		title.setFont(font);
		
		// list tableViewer
		RankListTableViewer rankTableViewer = new RankListTableViewer(parent);
		rankTableViewer.setInput(RankDataHandler.readRankList());
		
		// dispose listener
		parent.addDisposeListener(new DisposeListener() {
			@Override
			public void widgetDisposed(DisposeEvent arg0) {
				font.dispose();
			}
		});

		return dialogArea;
	}
	
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		createButton(parent, CANCEL, "닫기", false);
	}

	@Override
	protected Point getInitialSize() {
		return new Point(380, 400);
	}

}
