package baseball.rank;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RankDataHandler {

	private static final String RANK_DATA_FILE = "resource/rank.csv";

	public static Rank[] readRankList() {
		// 랭킹 파일을 읽어 등수를 계산하여 출력한다.
		FileReader reader = null;
		BufferedReader br = null;

		List<Rank> ranks = new ArrayList<>();
		try {
			br = new BufferedReader(reader = new FileReader(RANK_DATA_FILE));

			String rankLog = null;
			while ((rankLog = br.readLine()) != null) {
				//
				String[] split = rankLog.split(",");
				Rank rank = new Rank(split[0], Integer.parseInt(split[1]),
						Integer.parseInt(split[2]));
				ranks.add(rank);
			}
			Collections.sort(ranks);
			
			int rank = 1;
			for (Rank aRank : ranks) {
				aRank.setRank(rank);
				rank++;
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)     br.close();
				if (reader != null) reader.close();
			} catch (IOException e) { }
		}
		
		Rank[] rankArray = new Rank[ranks.size()];
		ranks.toArray(rankArray);
		return rankArray;
	}
	
	public static void saveLog(String playerName, int elapsedTime, int tryCount) {
		//
		String logText = playerName + "," + elapsedTime + "," + tryCount;
		
		FileWriter writer = null;
		try {
			writer = new FileWriter(RANK_DATA_FILE, true);
			writer.write(logText + "\n");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (writer != null) writer.close();
			} catch (IOException e) {
			}
		}
	}
}
