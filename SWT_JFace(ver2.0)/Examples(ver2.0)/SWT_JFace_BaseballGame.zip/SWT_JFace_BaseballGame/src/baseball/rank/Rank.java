package baseball.rank;

public class Rank implements Comparable<Rank> {
	
	private int rank;
	private String playerName;
	private int elapsedTime;
	private int tryCount;
	
	public Rank(String playerName, int elapsedTime, int tryCount) {
		//
		this.playerName = playerName;
		this.elapsedTime = elapsedTime;
		this.tryCount = tryCount;
	}
	
	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public int getElapsedTime() {
		return elapsedTime;
	}
	public void setElapsedTime(int elapsedTime) {
		this.elapsedTime = elapsedTime;
	}
	public int getTryCount() {
		return tryCount;
	}
	public void setTryCount(int tryCount) {
		this.tryCount = tryCount;
	}
	
	public int getScore() {
		return elapsedTime + tryCount;
	}

	@Override
	public int compareTo(Rank o) {
		//
		if (getScore() > o.getScore()) return 1;
		else if (getScore() < o.getScore()) return -1;
		return 0;
	}
}
