package baseball.rank;

import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

public class RankLabelProvider extends LabelProvider implements ITableLabelProvider {

	@Override
	public Image getColumnImage(Object element, int columnIndex) {
		// 
		return null;
	}

	@Override
	public String getColumnText(Object element, int columnIndex) {
		// 
		Rank rank = (Rank) element;
		
		switch (columnIndex) {
		case 0:
			return String.valueOf(rank.getRank());
		case 1:
			return rank.getPlayerName();
		case 2:
			return String.valueOf(rank.getElapsedTime());
		case 3:
			return String.valueOf(rank.getTryCount());
		default:
			return "";
		}
	}


}
