package baseball;

public interface Dashboard {
	//
	void addMessage(String message);
}
