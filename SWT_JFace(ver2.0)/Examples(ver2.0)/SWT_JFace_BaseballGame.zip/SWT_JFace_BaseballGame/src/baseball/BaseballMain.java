package baseball;

import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Text;

import baseball.actions.GameStartAction;
import baseball.actions.RankListAction;

public class BaseballMain extends ApplicationWindow implements Dashboard {

	private Text dashboard;
	
	public BaseballMain() {
		//
		super(null);
		addMenuBar();
	}

	@Override
	protected Control createContents(Composite parent) {
		// 
		parent.setBounds(300, 100, 500, 500);
		dashboard = new Text(parent, SWT.MULTI | SWT.WRAP | SWT.V_SCROLL);
		
		return parent;
	}

	@Override
	protected MenuManager createMenuManager() {
		// 
		MenuManager main = new MenuManager(null);
		MenuManager sub = new MenuManager("&Menu");
		main.add(sub);
		
		sub.add(new GameStartAction(this));
		sub.add(new RankListAction());
		
		return main;
	}
	
	public static void main(String[] args) {
		//
		BaseballMain main = new BaseballMain();
		main.setBlockOnOpen(true);
		main.open();
		
		Display.getCurrent().dispose();
	}

	@Override
	public void addMessage(String message) {
		// 
		dashboard.append("\n" + message);
	}
}
