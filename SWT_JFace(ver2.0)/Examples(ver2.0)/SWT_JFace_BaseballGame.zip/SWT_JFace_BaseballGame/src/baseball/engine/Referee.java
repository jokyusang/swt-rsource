package baseball.engine;

import baseball.Dashboard;


public class Referee {
	
	private Ball answerBall;
	private Dashboard dashboard;

	public Referee(Dashboard dashboard) {
		//
		this.dashboard = dashboard;
	}

	public void createAnswerBall() {
		//
		// 
//		Random rand = new Random(System.currentTimeMillis());
//
//		Set<Integer> numberSet = new HashSet<>();
//		while(true) {
//			int randomNumber = rand.nextInt(10);
//			if (randomNumber == 0) continue;
//			
//			numberSet.add(randomNumber);
//			
//			if (numberSet.size() == 3) {
//				break;
//			}
//		}
//		
//		Integer[] arr = new Integer[3];
//		numberSet.toArray(arr);
//		
//		this.answerBall = new Ball(arr[0], arr[1], arr[2]);
		this.answerBall = new Ball(3, 4, 5);
		
		// add message
		dashboard.addMessage("심판이 정답값을 생성하였습니다.");
	}
	
	public boolean decide(Ball userBall) {
		//
		int ballCount = this.answerBall.getBallCount(userBall);
		int strikeCount = this.answerBall.getStrikeCount(userBall);
		
		// add message
		dashboard.addMessage("Strike:" + strikeCount + ", Ball:" + ballCount);
		
		if (strikeCount == 3) {
			return true;
		}
		
		return false;
	}
}
