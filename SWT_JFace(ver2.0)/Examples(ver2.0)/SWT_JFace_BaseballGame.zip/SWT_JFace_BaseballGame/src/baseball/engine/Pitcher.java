package baseball.engine;

import org.eclipse.jface.dialogs.IInputValidator;
import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import baseball.Dashboard;

public class Pitcher {
	private Dashboard dashboard;

	public Pitcher(Dashboard dashboard) {
		// 
		this.dashboard = dashboard;
	}

	//
	public Ball throwBall() {
		//
		Shell shell = Display.getCurrent().getActiveShell();
		InputDialog dialog = new InputDialog(
				shell, 
				"숫자 입력", 
				"숫자 세개를 입력하세요 (예. 1 3 5)", 
				"", 
				new UserBallValidator());

		int[] nums = new int[3];
		if (dialog.open() == Window.OK) {
			String value = dialog.getValue();
			
			String[] split = value.split(" ");
			for (int i = 0; i < 3; i++) {
				nums[i] = Integer.parseInt(split[i]);
			}
			// add message
			dashboard.addMessage("입력한 숫자 : [" + nums[0] + "," + nums[1] + "," + nums[2] + "]");
			return new Ball(nums[0], nums[1], nums[2]);
		} else {
			// add message
			dashboard.addMessage("포기하지 마세요. 기회는 소중합니다.");
		}
		return null;
	}
	
	//
	class UserBallValidator implements IInputValidator {

		@Override
		public String isValid(String value) {
			// 
			String[] nums = value.split(" ");
			if (value.length() == 0) {
				return "";
			} else if (value.length() != 5 || nums.length != 3) {
				return "값을 형식에 맞게 입력하세요.";
			} else {
				for (String num : nums) {
					if (!Character.isDigit(num.charAt(0))) {
						return "숫자만 입력할 수 있습니다.";
					}
				}
			}
			return null;
		}
	}
}
