package baseball.engine;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import baseball.Dashboard;

public class GameEngine {
	
	private Pitcher pitcher;
	private Referee referee;
	private Dashboard dashboard;
	
	public GameEngine(Dashboard dashboard) {
		//
		this.dashboard = dashboard;
	}
	
	public void prepare() {
		//
		this.referee = new Referee(dashboard);
		this.pitcher = new Pitcher(dashboard);
		
		// 정답값 생성
		this.referee.createAnswerBall();
	}
	
	public int start() {
		//
		boolean gameClear = false;
		for (int i = 1; i <= 10; i++) {
			//
			dashboard.addMessage("\n총 10회 중" + i + "번째 도전입니다.");
			
			Ball userBall = this.pitcher.throwBall();
			if (userBall != null) {
				gameClear = this.referee.decide(userBall);
			}
			
			if (gameClear == true) {
				Shell shell = Display.getCurrent().getActiveShell();
				MessageDialog.openInformation(
						shell, "게임안내", "You are winner~!");
				
				return i;
			}
		}
		
		dashboard.addMessage("Game over~");
		return -1;
	}
}




