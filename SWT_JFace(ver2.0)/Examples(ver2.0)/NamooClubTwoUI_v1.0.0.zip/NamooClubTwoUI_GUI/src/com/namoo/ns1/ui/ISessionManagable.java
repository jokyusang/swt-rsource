package com.namoo.ns1.ui;

public interface ISessionManagable {

	void setLoginStatus(boolean isLogin);
}
