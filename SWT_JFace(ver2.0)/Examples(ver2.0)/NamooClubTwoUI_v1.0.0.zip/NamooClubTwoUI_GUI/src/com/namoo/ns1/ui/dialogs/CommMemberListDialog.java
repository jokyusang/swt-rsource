package com.namoo.ns1.ui.dialogs;

import java.util.List;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

import com.namoo.ns1.service.facade.CommunityService;
import com.namoo.ns1.service.factory.NamooClubServiceFactory;
import com.namoo.ns1.ui.provider.CommunityMemberLabelProvider;

import dom.entity.Community;
import dom.entity.CommunityMember;

public class CommMemberListDialog extends TitleAreaDialog {
	
	private Community community;
	private CommunityService communityService;
	
	/**
	 * Create the dialog.
	 * @param parentShell
	 */
	public CommMemberListDialog(Shell parentShell, Community community) {
		super(parentShell);
		this.community = community;
		this.communityService = NamooClubServiceFactory.getInstance().getCommunityService();
	}

	/**
	 * Create contents of the dialog.
	 * @param parent
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		//
		setTitle(community.getName());
		setMessage(community.getDescription());
		Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);
		container.setLayout(new GridLayout(1, false));
		container.setLayoutData(new GridData(GridData.FILL_BOTH));
		
		Group group = new Group(container, SWT.NONE);
		group.setText("회원목록");
		group.setLayout(new GridLayout(1, false));
		group.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		
		TableViewer tableViewer = new TableViewer(group, SWT.BORDER | SWT.FULL_SELECTION);
		Table table = tableViewer.getTable();
		table.setLinesVisible(true);
		table.setHeaderVisible(true);
		table.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));

		String[] columnNames = new String[] {"이름", "이메일"};
		int[] columnWidths = new int[] {150, 260};
		int[] columnAligns = new int[] {SWT.LEFT, SWT.LEFT};
		
		int columnLength = columnNames.length;
		for (int i = 0; i < columnLength; i++) {
			TableViewerColumn tableViewerColumn = new TableViewerColumn(tableViewer, columnAligns[i]);
			TableColumn column = tableViewerColumn.getColumn();
			column.setText(columnNames[i]);
			column.setWidth(columnWidths[i]);
		}
		
		tableViewer.setContentProvider(new ArrayContentProvider());
		tableViewer.setLabelProvider(new CommunityMemberLabelProvider());
		
		List<CommunityMember> members = communityService.findAllCommunityMember(community.getName());
		tableViewer.setInput(members);
		
		return area;
	}

	/**
	 * Create contents of the button bar.
	 * @param parent
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		//
		createButton(parent, IDialogConstants.OK_ID, "확인", true);
		createButton(parent, IDialogConstants.CANCEL_ID, "취소", false);
	}

	/**
	 * Return the initial size of the dialog.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(450, 377);
	}

	@Override
	protected void configureShell(Shell newShell) {
		//
		super.configureShell(newShell);
		newShell.setText("커뮤니티 회원목록");
	}
}
