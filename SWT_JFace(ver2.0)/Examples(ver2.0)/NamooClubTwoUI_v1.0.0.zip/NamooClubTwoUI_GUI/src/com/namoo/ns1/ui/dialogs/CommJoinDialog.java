package com.namoo.ns1.ui.dialogs;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.namoo.ns1.service.facade.CommunityService;
import com.namoo.ns1.service.facade.TownerService;
import com.namoo.ns1.service.factory.NamooClubServiceFactory;

import dom.entity.Community;

/**
 * 커뮤니티 회원가입 다이얼로그
 * 
 * @author Kimgisa
 */
public class CommJoinDialog extends TitleAreaDialog {
	//
	// widgets
	private Text inputNameText;
	private Text inputEmailText;
	private Text inputPasswordText;
	private Button checkDupBtn;
	
	// 이메일 중복체크
	private boolean availableEmail;
	private String name;
	private String email;
	private String password;
	
	private Community community;
	private CommunityService communityService;
	private TownerService townerService;

	/**
	 * Create the dialog.
	 * @param parentShell
	 */
	public CommJoinDialog(Shell parentShell, Community community) {
		//
		super(parentShell);
		this.community = community;
		this.communityService = NamooClubServiceFactory.getInstance().getCommunityService();
		this.townerService = NamooClubServiceFactory.getInstance().getTownerService();
	}

	/**
	 * Create contents of the dialog.
	 * @param parent
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		//
		setTitle(community.getName());
		setMessage(community.getDescription());

		Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);
		container.setLayout(new GridLayout(2, false));
		container.setLayoutData(new GridData(GridData.FILL_BOTH));
		
		Group memberInfoGrp = new Group(container, SWT.NONE);
		memberInfoGrp.setText("신규 회원정보");
		memberInfoGrp.setLayout(new GridLayout(3, false));
		memberInfoGrp.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 2, 1));
		
		Label nameLabel = new Label(memberInfoGrp, SWT.NONE);
		nameLabel.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		nameLabel.setText("이름 :");
		
		inputNameText = new Text(memberInfoGrp, SWT.BORDER);
		inputNameText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		new Label(memberInfoGrp, SWT.NONE);
		
		Label emailLabel = new Label(memberInfoGrp, SWT.NONE);
		emailLabel.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		emailLabel.setText("이메일 :");
		
		inputEmailText = new Text(memberInfoGrp, SWT.BORDER);
		inputEmailText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		checkDupBtn = new Button(memberInfoGrp, SWT.NONE);
		checkDupBtn.setText("중복체크");
		
		Label passwordLabel = new Label(memberInfoGrp, SWT.NONE);
		passwordLabel.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		passwordLabel.setText("패스워드 :");
		
		inputPasswordText = new Text(memberInfoGrp, SWT.BORDER);
		inputPasswordText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		new Label(memberInfoGrp, SWT.NONE);

		addEventListener();
		
		return area;
	}

	private void addEventListener() {
		//
		checkDupBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				// 
				String communityName = community.getName();
				String email = inputEmailText.getText();
				
				if (email.length() == 0) {
					MessageDialog.openError(getParentShell(), "오류메시지", 
						"이메일을 입력하세요.");
					inputEmailText.setFocus();
					return;
				}
				
				// 커뮤니티 회원가입 여부 체크
				if (communityService.findCommunityMember(communityName, email) != null) {
					MessageDialog.openError(getParentShell(), "오류메시지", 
							"이미 커뮤니티에 가입된 회원입니다.");
					availableEmail = false;
					return;
				}
				
				// 주민 등록여부 체크
				if (townerService.findTowner(email) != null) {
					MessageDialog.openError(getParentShell(), "오류메시지", 
							"이미 주민으로 등록된 회원입니다. 메인화면에서 로그인하세요.");
					availableEmail = false;
					return;
				}
				
				MessageDialog.openInformation(getParentShell(), "정보메시지", 
						"사용가능한 이메일입니다.");
				
				checkDupBtn.setEnabled(false);
				availableEmail = true;
			}
		});
		
		inputEmailText.addModifyListener(new ModifyListener() {
			@Override
			public void modifyText(ModifyEvent arg0) {
				//
				availableEmail = false;
				checkDupBtn.setEnabled(true);
			}
		});
	}

	@Override
	protected void okPressed() {
		//
		if (availableEmail == false) {
			MessageDialog.openError(getParentShell(), 
				"오류메시지", "이메일 중복체크를 하세요.");
			return;
		}
		
		name = inputNameText.getText();
		email = inputEmailText.getText();
		password = inputPasswordText.getText();
		
		if (name.length() > 0 && email.length() > 0 && password.length() > 0) {
			super.okPressed();
			return;
		} else {
			MessageDialog.openError(getParentShell(), 
				"오류메시지", "모든 정보를 빠짐없이 입력해주세요.");
			return;
		}
	}

	/**
	 * Create contents of the button bar.
	 * @param parent
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		createButton(parent, IDialogConstants.OK_ID, "회원가입", true);
		createButton(parent, IDialogConstants.CANCEL_ID, "취소", false);
	}

	/**
	 * Return the initial size of the dialog.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(450, 266);
	}
	
	@Override
	protected void configureShell(Shell newShell) {
		//
		super.configureShell(newShell);
		newShell.setText("커뮤니티 가입");
	}

	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}
	
	public String getPassword() {
		return password;
	}
}
