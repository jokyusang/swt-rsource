package com.namoo.ns1.ui.dialogs;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class LoginDialog extends Dialog {
	//
	private Text inputEmailText;
	private Text inputPaswordText;
	
	//
	private String email;
	private String password;

	/**
	 * Create the dialog.
	 * @param parentShell
	 */
	public LoginDialog(Shell parentShell) {
		super(parentShell);
	}

	/**
	 * Create contents of the dialog.
	 * @param parent
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		Composite container = (Composite) super.createDialogArea(parent);
		container.setLayout(new GridLayout(1, false));
		
		Group grpLogin = new Group(container, SWT.NONE);
		grpLogin.setLayout(new GridLayout(2, false));
		GridData gd_grpLogin = new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1);
		gd_grpLogin.heightHint = 120;
		grpLogin.setLayoutData(gd_grpLogin);
		grpLogin.setText("회원 로그인");
		
		Label emailLabel = new Label(grpLogin, SWT.NONE);
		emailLabel.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		emailLabel.setText("이메일 :");
		
		inputEmailText = new Text(grpLogin, SWT.BORDER);
		inputEmailText.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		
		Label lblNewLabel_1 = new Label(grpLogin, SWT.NONE);
		lblNewLabel_1.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblNewLabel_1.setText("패스워드 :");
		
		inputPaswordText = new Text(grpLogin, SWT.BORDER | SWT.PASSWORD);
		inputPaswordText.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		
		return container;
	}
	
	/**
	 * Create contents of the button bar.
	 * @param parent
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		//
		createButton(parent, IDialogConstants.OK_ID, "로그인", true);
		createButton(parent, IDialogConstants.CANCEL_ID, "취소", false);
	}
	
	@Override
	protected void okPressed() {
		// 
		email = inputEmailText.getText();
		password = inputPaswordText.getText();
		
		if (email.length() > 0 && password.length() > 0) {
			super.okPressed();
		} else {
			MessageDialog.openError(
					getParentShell(), 
					"오류메시지", 
					"빈칸 없이 모두 입력하세요.");
		}
	}

	/**
	 * Return the initial size of the dialog.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(362, 173);
	}
	
	@Override
	protected void configureShell(Shell newShell) {
		//
		super.configureShell(newShell);
		newShell.setText("로그인");
	}

	public String getEmail() {
		return email;
	}

	public String getPassword() {
		return password;
	}
}
