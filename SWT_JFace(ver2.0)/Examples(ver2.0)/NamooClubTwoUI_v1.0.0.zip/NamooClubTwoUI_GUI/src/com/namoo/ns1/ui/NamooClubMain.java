package com.namoo.ns1.ui;

import java.util.List;

import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.action.StatusLineManager;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

import com.namoo.ns1.service.facade.CommunityService;
import com.namoo.ns1.service.factory.NamooClubServiceFactory;
import com.namoo.ns1.ui.actions.ExitAction;
import com.namoo.ns1.ui.actions.LoginAction;
import com.namoo.ns1.ui.actions.LogoutAction;
import com.namoo.ns1.ui.dialogs.CommDtlDialog;
import com.namoo.ns1.ui.dialogs.CommRegDialog;
import com.namoo.ns1.ui.pres.PresCommunity;
import com.namoo.ns1.ui.provider.CommunityContentProvider;
import com.namoo.ns1.ui.provider.CommunityLabelProvider;
import com.namoo.ns1.ui.session.SessionManager;

import dom.entity.Community;

public class NamooClubMain extends ApplicationWindow implements IStatusMessage, ISessionManagable{
	//
	private CommunityService communityService;
	
	// widgets
	private TableViewer commListTableViewer;
	private Button registCommBtn;
	
	private StatusLineManager statusLineManager = new StatusLineManager();
	
	// actions
	private ExitAction exitAction;
	private LoginAction loginAction;
	private LogoutAction logoutAction;

	/**
	 * Create the application window.
	 */
	public NamooClubMain() {
		//
		super(null);
		createActions();
		addStatusLine();
		addMenuBar();
		addToolBar(SWT.FLAT | SWT.WRAP);
		
		communityService = NamooClubServiceFactory.getInstance().getCommunityService();
		SessionManager.getInstance().setStatusMessage(this);
	}

	/**
	 * Create contents of the application window.
	 * @param parent
	 */
	@Override
	protected Control createContents(Composite parent) {
		//
		Composite container = new Composite(parent, SWT.NONE);
		container.setLayout(new GridLayout(2, false));
		
		Label commListLabel = new Label(container, SWT.NONE);
		commListLabel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		commListLabel.setText("커뮤니티 목록");
		registCommBtn = new Button(container, SWT.NONE);
		registCommBtn.setText("커뮤니티 개설");
		
		// Draw TableViewer for community list
		commListTableViewer = new TableViewer(container, SWT.BORDER | SWT.FULL_SELECTION);
		Table table = commListTableViewer.getTable();
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		GridData gd_table = new GridData(SWT.FILL, SWT.FILL, true, true, 2, 1);
		gd_table.heightHint = 119;
		table.setLayoutData(gd_table);
		
		Label label = new Label(container, SWT.NONE);
		label.setEnabled(false);
		label.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		label.setText("커뮤니티를 더블클릭하면 상세정보를 보실 수 있습니다.");
		
		String[] columnNames = new String[] {"순번", "커뮤니티명", "관리자명", "회원 수"};
		int[] columnWidths = new int[] {60, 200, 80, 80};
		int[] columnAligns = new int[] {SWT.LEFT, SWT.LEFT, SWT.LEFT, SWT.LEFT};
		
		int columnLength = columnNames.length;
		for (int i = 0; i < columnLength; i++) {
			TableViewerColumn tableViewerColumn = new TableViewerColumn(commListTableViewer, columnAligns[i]);
			TableColumn column = tableViewerColumn.getColumn();
			column.setText(columnNames[i]);
			column.setWidth(columnWidths[i]);
		}
		
		commListTableViewer.setContentProvider(new CommunityContentProvider());
		commListTableViewer.setLabelProvider(new CommunityLabelProvider());
		
		refreshCommunityList();
		addEventListener();
		
		return container;
	}

	private void addEventListener() {
		// 
		commListTableViewer.addDoubleClickListener(new IDoubleClickListener() {
			@Override
			public void doubleClick(DoubleClickEvent event) {
				// 
				IStructuredSelection selection = (IStructuredSelection) event.getSelection();
				PresCommunity community = (PresCommunity) selection.getFirstElement();
				openCommunityDetailDialog(community);
				
				refreshCommunityList();
			}
		});
		
		registCommBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				// 
				CommRegDialog dialog = new CommRegDialog(getParentShell());
				if (dialog.open() == Window.OK) {
					MessageDialog.openInformation(getParentShell(), "정보메시지", 
						"커뮤니티가 개설되었습니다.");
					
					refreshCommunityList();
				};
			}

		});
	}

	private void refreshCommunityList() {
		// 
		List<Community> communities = communityService.findAllCommunities();
		commListTableViewer.setInput(communities);
	}
	
	private void openCommunityDetailDialog(PresCommunity presCommunity) {
		// 
		CommDtlDialog dialog = new CommDtlDialog(
				getParentShell(), presCommunity.getCommunity());
		
		dialog.open();
		
	}
	/**
	 * Create the actions.
	 */
	private void createActions() {
		// 
		exitAction = new ExitAction(this);
		loginAction = new LoginAction(this);
		logoutAction = new LogoutAction(this);
	}

	/**
	 * Create the menu manager.
	 * @return the menu manager
	 */
	@Override
	protected MenuManager createMenuManager() {
		//
		MenuManager menuManager = new MenuManager(); // root
		MenuManager menu = new MenuManager("&Menu");
		menuManager.add(menu);
		menu.add(loginAction);
		menu.add(logoutAction);
		menu.add(new Separator());
		menu.add(exitAction);
		
		logoutAction.setEnabled(false);
		menu.update(true);

		return menuManager;
	}

	@Override
	protected ToolBarManager createToolBarManager(int style) {
		// 
		ToolBarManager manager = new ToolBarManager(style);
		manager.add(loginAction);
		manager.add(logoutAction);
		return manager;
	}

	/**
	 * Create the status line manager.
	 * @return the status line manager
	 */
	@Override
	protected StatusLineManager createStatusLineManager() {
		//
		return statusLineManager;
	}

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String args[]) {
		//
		try {
			NamooClubMain window = new NamooClubMain();
			window.setBlockOnOpen(true);
			window.open();
			Display.getCurrent().dispose();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Configure the shell.
	 * @param newShell
	 */
	@Override
	protected void configureShell(Shell newShell) {
		super.configureShell(newShell);
		newShell.setText("Namoo Club v0.1");
	}

	/**
	 * Return the initial size of the window.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(450, 300);
	}

	@Override
	public void setMessage(String message) {
		//
		statusLineManager.setMessage(message);
	}

	@Override
	public void setLoginStatus(boolean isLogin) {
		// 
		if (isLogin) {
			loginAction.setEnabled(false);
			logoutAction.setEnabled(true);
		} else {
			loginAction.setEnabled(true);
			logoutAction.setEnabled(false);
		}
		getMenuBarManager().update(true);
		getToolBarManager().update(true);
	}
}
