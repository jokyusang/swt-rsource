package com.namoo.ns1.ui.provider;

import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

import dom.entity.CommunityMember;

public class CommunityMemberLabelProvider extends LabelProvider implements ITableLabelProvider {

	@Override
	public Image getColumnImage(Object element, int columnIndex) {
		// 
		return null;
	}

	@Override
	public String getColumnText(Object element, int columnIndex) {
		//
		CommunityMember member = (CommunityMember) element;
		
		switch (columnIndex) {
		case 0:
			return member.getName();
		case 1:
			return member.getEmail();
		default:
			break;
		}
		return null;
	}
}
