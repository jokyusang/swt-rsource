package com.namoo.ns1.ui.provider;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.Viewer;

import com.namoo.ns1.ui.pres.PresCommunity;

import dom.entity.Community;

public class CommunityContentProvider implements IStructuredContentProvider {

	@Override
	public void dispose() {
		//
	}

	@Override
	public void inputChanged(Viewer arg0, Object arg1, Object arg2) {
		//
	}

	@Override
	public Object[] getElements(Object element) {
		// 
		@SuppressWarnings("unchecked")
		List<Community> communities = (List<Community>) element;
		List<PresCommunity> presCommunities = new ArrayList<>();
		
		int seq = 1;
		for (Community community : communities) {
			presCommunities.add(new PresCommunity(seq, community));
			seq++;
		}
		
		return presCommunities.toArray();
	}
}
