package com.namoo.ns1.ui.actions;

import java.net.MalformedURLException;
import java.net.URL;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.widgets.Display;

import com.namoo.ns1.ui.ISessionManagable;
import com.namoo.ns1.ui.session.SessionManager;

public class LogoutAction extends Action {
	
	private ISessionManagable sessionManagable;

	public LogoutAction(ISessionManagable sessionManagable) {
		//
		super("&Logout@Ctrl+X");
		setToolTipText("Logout");
		this.sessionManagable = sessionManagable;
		
		try {
			setImageDescriptor(ImageDescriptor.createFromURL(new URL("file:icons/logout.ico")));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		// 
		boolean confirm = MessageDialog.openConfirm(Display.getCurrent().getActiveShell(), 
				"확인메시지", "로그아웃하시겠습니까?");
		
		if (confirm) {
			SessionManager sessionManager = SessionManager.getInstance();
			sessionManager.logout();
			sessionManagable.setLoginStatus(false);
		}
	}
}
