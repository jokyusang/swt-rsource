package com.namoo.ns1.service.logic.exception;

public class NamooRuntimeException extends RuntimeException {

	private static final long serialVersionUID = 1024872161120504103L;
	
	public NamooRuntimeException(String msg) {
		//
		super(msg);
	}
}
