package com.namoo.ns1.ui.provider;

import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

import com.namoo.ns1.ui.pres.PresCommunity;

public class CommunityLabelProvider extends LabelProvider implements ITableLabelProvider {

	@Override
	public Image getColumnImage(Object element, int columnIndex) {
		//
		return null;
	}

	@Override
	public String getColumnText(Object element, int columnIndex) {
		// 
		PresCommunity community = (PresCommunity) element;
		
		switch (columnIndex) {
		case 0: // 순번
			return community.getSeq() + "";
		case 1: // 커뮤니티명
			return community.getName();
		case 2: // 관리자명
			return community.getManagerName();
		case 3: // 회원수
			return community.getCountOfMember() + "";
		default:
			break;
		}
		return null;
	}

}
