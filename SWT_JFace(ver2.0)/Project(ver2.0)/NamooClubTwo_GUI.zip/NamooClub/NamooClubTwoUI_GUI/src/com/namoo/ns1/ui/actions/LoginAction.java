package com.namoo.ns1.ui.actions;

import java.net.MalformedURLException;
import java.net.URL;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.widgets.Display;

import com.namoo.ns1.ui.ISessionManagable;
import com.namoo.ns1.ui.dialogs.LoginDialog;
import com.namoo.ns1.ui.session.SessionManager;

public class LoginAction extends Action {
	
	private ISessionManagable sessionManagable;

	public LoginAction(ISessionManagable sessionManagable) {
		//
		super("&Login@Ctrl+O");
		setToolTipText("Login");
		this.sessionManagable = sessionManagable;
		
		try {
			setImageDescriptor(ImageDescriptor.createFromURL(new URL("file:icons/login.ico")));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		// 
		LoginDialog dialog = new LoginDialog(Display.getCurrent().getActiveShell());
		if (dialog.open() == Window.OK) {
			String email = dialog.getEmail();
			String password = dialog.getPassword();
			
			SessionManager sessionManager = SessionManager.getInstance();
			if (sessionManager.login(email, password)) {
				sessionManagable.setLoginStatus(true);
				
			} else {
				MessageDialog.openError(Display.getCurrent().getActiveShell(), 
						"로그인 오류", "회원정보가 올바르지 않습니다.");
				sessionManagable.setLoginStatus(false);
			}
		}
	}
}
