package com.namoo.ns1.ui.session;

import com.namoo.ns1.service.facade.TownerService;
import com.namoo.ns1.service.factory.NamooClubServiceFactory;
import com.namoo.ns1.ui.IStatusMessage;

import dom.entity.SocialPerson;

/**
 * 로그인 세션 관리자 클래스 (싱글톤)
 * 
 * @author Kimgisa
 *
 */
public class SessionManager {
	
	private static SessionManager instance = new SessionManager();
	
	private TownerService townerService;
	private SocialPerson loginTowner;

	private IStatusMessage statusMessage;
	
	private SessionManager() {
		//
		townerService = NamooClubServiceFactory.getInstance().getTownerService();
	}
	
	public static SessionManager getInstance() {
		//
		return instance;
	}
	
	//--------------------------------------------------------------------------
	
	public boolean isLogin() {
		//
		return (loginTowner != null) ? true : false;
	}

	public String getLoginEmail() {
		//
		if (isLogin()) {
			return loginTowner.getEmail();
		}
		return null;
	}
	
	public boolean login(String email, String password) {
		//
		if (townerService.loginAsTowner(email, password)) {
			loginTowner = townerService.findTowner(email);
			statusMessage.setMessage(loginTowner.getName() + "님이 로그인되었습니다.");
			return true;
		} else {
			logout();
			return false;
		}
	}
	
	public String getLoginName() {
		//
		if (isLogin()) {
			return loginTowner.getName();
		}
		return null;
	}

	public void setStatusMessage(IStatusMessage statusMessage) {
		// 
		this.statusMessage = statusMessage;
	}

	public void logout() {
		//
		loginTowner = null;
		statusMessage.setMessage("로그인 상태가 아닙니다.");
		
	}

	public String getLoginPassword() {
		// 
		if (isLogin()) {
			return loginTowner.getPassword();
		}
		return null;
	}
}
