package com.namoo.ns1.ui.pres;

import dom.entity.Community;

public class PresCommunity {

	private int seq;
	private Community community;
	
	public PresCommunity(int seq, Community community) {
		this.seq = seq;
		this.community = community;
	}
	
	public int getSeq() {
		return seq;
	}
	
	public String getName() {
		return community.getName();
	}
	
	public String getManagerName() {
		return community.getManager().getName();
	}
	
	public int getCountOfMember() {
		return community.getMembers().size();
	}

	public Community getCommunity() {
		return community;
	}
}
