package com.namoo.ns1.ui.dialogs;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Text;

import com.namoo.ns1.service.facade.CommunityService;
import com.namoo.ns1.service.factory.NamooClubServiceFactory;
import com.namoo.ns1.service.logic.exception.NamooRuntimeException;
import com.namoo.ns1.ui.session.SessionManager;

import dom.entity.Community;

/**
 * 커뮤니티 상세정보 다이얼로그
 * 
 * @author Kimgisa
 *
 */
public class CommDtlDialog extends TitleAreaDialog {
	private static final Object MODE_JOIN = "1";
	private static final Object MODE_WITHDRAWAL = "2";
	//
	// widgets
	private Text adminNameText;
	private Text adminEmailText;
	private Button joinBtn;
	private Button memberListBtn;
	
	// input
	private Community community;
	
	// service
	private CommunityService communityService;
	

	/**
	 * Create the dialog.
	 * @param parentShell
	 */
	public CommDtlDialog(Shell parentShell, Community community) {
		super(parentShell);
		this.community = community;
		this.communityService = NamooClubServiceFactory.getInstance().getCommunityService();
	}

	/**
	 * Create contents of the dialog.
	 * @param parent
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		//
		setTitle(community.getName());
		setMessage(community.getDescription());
		
		Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);
		container.setLayout(new GridLayout(2, false));
		container.setLayoutData(new GridData(GridData.FILL_BOTH));
		
		joinBtn = new Button(container, SWT.NONE);
		if (isLoginAndJoin()) { // 이미 가입되어 있고 로그인이 된 경우
			joinBtn.setText("커뮤니티 탈퇴");
			joinBtn.setData("mode", MODE_WITHDRAWAL);
		} else {
			joinBtn.setText("커뮤니티 가입");
			joinBtn.setData("mode", MODE_JOIN);
		}
		memberListBtn = new Button(container, SWT.NONE);
		memberListBtn.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		memberListBtn.setText("회원 목록");
		
		Group adminGrp = new Group(container, SWT.NONE);
		adminGrp.setLayout(new GridLayout(2, false));
		GridData gd_adminGrp = new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1);
		gd_adminGrp.heightHint = 60;
		adminGrp.setLayoutData(gd_adminGrp);
		adminGrp.setText("관리자 정보");
		
		Label adminNameLabel = new Label(adminGrp, SWT.NONE);
		adminNameLabel.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		adminNameLabel.setText("이름 :");
		
		adminNameText = new Text(adminGrp, SWT.BORDER);
		adminNameText.setEditable(false);
		adminNameText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		adminNameText.setText(community.getManager().getName());
		
		Label adminEmailLabel = new Label(adminGrp, SWT.NONE);
		adminEmailLabel.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		adminEmailLabel.setText("이메일 :");
		
		adminEmailText = new Text(adminGrp, SWT.BORDER);
		adminEmailText.setEditable(false);
		adminEmailText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		adminEmailText.setText(community.getManager().getEmail());
		
		Group clubGrp = new Group(container, SWT.NONE);
		clubGrp.setLayout(new GridLayout(1, false));
		clubGrp.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 2, 1));
		clubGrp.setText("클럽 목록");
		
		TableViewer tableViewer = new TableViewer(clubGrp, SWT.BORDER | SWT.FULL_SELECTION);
		Table table = tableViewer.getTable();
		table.setLinesVisible(true);
		table.setHeaderVisible(true);
		table.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		
		String[] columnNames = new String[] {"순번", "클럽명", "개설일자", "상태"};
		int[] columnWidths = new int[] {50, 100, 100, 80};
		int[] columnAligns = new int[] {SWT.LEFT, SWT.LEFT, SWT.CENTER, SWT.CENTER};
		
		int columnLength = columnNames.length;
		for (int i = 0; i < columnLength; i++) {
			TableViewerColumn tableViewerColumn = new TableViewerColumn(tableViewer, columnAligns[i]);
			TableColumn column = tableViewerColumn.getColumn();
			column.setWidth(columnWidths[i]);
			column.setText(columnNames[i]);
		}
		
		addEventListener();
		return area;
	}

	private boolean isLoginAndJoin() {
		// 
		SessionManager sessionManager = SessionManager.getInstance();
		if (sessionManager.isLogin()) {
			String communityName = community.getName();
			String loginEmail = sessionManager.getLoginEmail();
			if (communityService.findCommunityMember(communityName, loginEmail) != null) {
				return true;
			}
		}
		return false;
	}

	private void addEventListener() {
		// 
		// 커뮤니티 가입 또는 탈퇴 버튼
		joinBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent evt) {
				//
				String communityName = community.getName();
				
				if (MODE_JOIN.equals(joinBtn.getData("mode"))) {
					handleJoinProcess();
				} else {
					boolean confirm = MessageDialog.openConfirm(getParentShell(), "확인메시지", 
						"정말로 커뮤니티에서 탈퇴하시겠습니까?");
					if (confirm) {
						String email = SessionManager.getInstance().getLoginEmail();
						communityService.withdrawalCommunity(communityName, email);
						
						MessageDialog.openInformation(getParentShell(), "정보메시지", 
							"커뮤니티에서 탈퇴하였습니다.");
					}
				}
			}
		});
		
		// 커뮤니티 회원조회 버튼
		memberListBtn.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				// 
				CommMemberListDialog dialog = new CommMemberListDialog(getParentShell(), community);
				dialog.open();
			}
		});
	}

	private void handleJoinProcess() {
		//
		String communityName = community.getName();
		SessionManager sessionManager = SessionManager.getInstance();
		if (sessionManager.isLogin()) {
			boolean confirm = MessageDialog.openConfirm(getParentShell(), 
					"커뮤니티 가입",  communityName + "에 가입하시겠습니까?");
			
			if (confirm) {
				String loginEmail = sessionManager.getLoginEmail();
				
				try {
					communityService.joinAsMember(communityName, loginEmail);
				} catch (NamooRuntimeException e) {
					MessageDialog.openError(getParentShell(), "오류메시지", e.getMessage());
					return;
				}
				openCompleteMessageDialog();
			}
		} else {
			//
			// open community join dialog
			CommJoinDialog dialog = new CommJoinDialog(getParentShell(), community);
			if (dialog.open() == Window.OK) {
				String name = dialog.getName();
				String email = dialog.getEmail();
				String password = dialog.getPassword();
				
				try {
					communityService.joinAsMember(communityName, name, email, password);
					sessionManager.login(email, password);
				} catch (NamooRuntimeException e) {
					MessageDialog.openError(getParentShell(), "오류메시지", e.getMessage());
					return;
				}
				openCompleteMessageDialog();
			}
		}
	}
	
	private void openCompleteMessageDialog() {
		//
		MessageDialog.openInformation(getParentShell(), "커뮤니티 가입", 
				community.getName() + "에 가입되었습니다.");
	}

	/**
	 * Create contents of the button bar.
	 * @param parent
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		createButton(parent, IDialogConstants.OK_ID, "확인", true);
		createButton(parent, IDialogConstants.CANCEL_ID, "닫기", false);
	}

	/**
	 * Return the initial size of the dialog.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(450, 399);
	}
	
	@Override
	protected void configureShell(Shell newShell) {
		//
		super.configureShell(newShell);
		newShell.setText("커뮤니티 상세정보");
	}
}
