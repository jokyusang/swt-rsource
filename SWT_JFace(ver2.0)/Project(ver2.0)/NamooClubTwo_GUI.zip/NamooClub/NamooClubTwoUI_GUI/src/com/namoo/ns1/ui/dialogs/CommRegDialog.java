package com.namoo.ns1.ui.dialogs;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.namoo.ns1.service.facade.CommunityService;
import com.namoo.ns1.service.facade.TownerService;
import com.namoo.ns1.service.factory.NamooClubServiceFactory;
import com.namoo.ns1.ui.session.SessionManager;

import dom.entity.Community;

/**
 * 커뮤니티 등록(개설) 다이얼로그
 * 
 * @author Kimgisa
 *
 */
public class CommRegDialog extends TitleAreaDialog {
	//
	private Text inputCommNameText;
	private Text inputCommDescText;
	private Text inputAdminNameText;
	private Text inputAdminEmailText;
	private Text inputAdminPasswordText;
	private Button checkDupCommNameBtn;
	private Button checkDupAdminEmailBtn;
	
	private boolean availableCommunity;
	private boolean availableAdminEmail;
	private Community registeredCommunity;
	
	private CommunityService communityService;
	private TownerService townerService;
	
	/**
	 * Create the dialog.
	 * @param parentShell
	 */
	public CommRegDialog(Shell parentShell) {
		super(parentShell);
		
		this.communityService = NamooClubServiceFactory.getInstance().getCommunityService();
		this.townerService = NamooClubServiceFactory.getInstance().getTownerService();
	}

	/**
	 * Create contents of the dialog.
	 * @param parent
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		//
		setMessage("새로운 커뮤니티를 개설하여 관심사를 공유하세요.");
		setTitle("커뮤니티 개설");
		
		Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);
		container.setLayout(new GridLayout(1, false));
		container.setLayoutData(new GridData(GridData.FILL_BOTH));
		
		Group basicInfoGrp = new Group(container, SWT.NONE);
		basicInfoGrp.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		basicInfoGrp.setText("커뮤니티 기본정보");
		basicInfoGrp.setLayout(new GridLayout(3, false));
		
		Label commNameLabel = new Label(basicInfoGrp, SWT.RIGHT);
		GridData gd_commNameLabel = new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1);
		gd_commNameLabel.widthHint = 80;
		commNameLabel.setLayoutData(gd_commNameLabel);
		commNameLabel.setText("커뮤니티명 :");
		
		inputCommNameText = new Text(basicInfoGrp, SWT.BORDER);
		inputCommNameText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		checkDupCommNameBtn = new Button(basicInfoGrp, SWT.NONE);
		checkDupCommNameBtn.setText("중복체크");
		
		Label commDescLabel = new Label(basicInfoGrp, SWT.RIGHT);
		GridData gd_lblCommdesc = new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1);
		gd_lblCommdesc.widthHint = 80;
		commDescLabel.setLayoutData(gd_lblCommdesc);
		commDescLabel.setText("소개문구 :");
		
		inputCommDescText = new Text(basicInfoGrp, SWT.BORDER | SWT.MULTI);
		GridData gd_inputCommDescText = new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1);
		gd_inputCommDescText.heightHint = 40;
		inputCommDescText.setLayoutData(gd_inputCommDescText);
		new Label(basicInfoGrp, SWT.NONE);
		
		Group adminGrp = new Group(container, SWT.NONE);
		adminGrp.setText("관리자 회원정보");
		adminGrp.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		adminGrp.setLayout(new GridLayout(3, false));
		
		Label nameLabel = new Label(adminGrp, SWT.RIGHT);
		GridData gd_nameLabel = new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1);
		gd_nameLabel.widthHint = 80;
		nameLabel.setLayoutData(gd_nameLabel);
		nameLabel.setText("이름 :");
		
		inputAdminNameText = new Text(adminGrp, SWT.BORDER);
		inputAdminNameText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		new Label(adminGrp, SWT.NONE);
		
		Label adminEmailLabel = new Label(adminGrp, SWT.RIGHT);
		adminEmailLabel.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		adminEmailLabel.setText("이메일 :");
		
		inputAdminEmailText = new Text(adminGrp, SWT.BORDER);
		inputAdminEmailText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		checkDupAdminEmailBtn = new Button(adminGrp, SWT.NONE);
		checkDupAdminEmailBtn.setText("중복체크");
		
		Label adminPasswordLabel = new Label(adminGrp, SWT.RIGHT);
		adminPasswordLabel.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		adminPasswordLabel.setText("패스워드 :");
		
		inputAdminPasswordText = new Text(adminGrp, SWT.BORDER | SWT.PASSWORD);
		inputAdminPasswordText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		new Label(adminGrp, SWT.NONE);
		
		Label noticeLabel = new Label(adminGrp, SWT.NONE);
		noticeLabel.setEnabled(false);
		GridData gd_noticeLabel = new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1);
		gd_noticeLabel.horizontalIndent = 20;
		noticeLabel.setLayoutData(gd_noticeLabel);
		noticeLabel.setText("커뮤니티를 개설한 회원은 관리자가 됩니다.");
		
		// 로그인된 사용자인 경우 관리자 정보를 채움
		SessionManager sessionManager = SessionManager.getInstance();
		if (sessionManager.isLogin()) {
			inputAdminNameText.setText(sessionManager.getLoginName());
			inputAdminEmailText.setText(sessionManager.getLoginEmail());
			inputAdminPasswordText.setText(sessionManager.getLoginPassword());
			
			inputAdminNameText.setEnabled(false);
			inputAdminEmailText.setEnabled(false);
			inputAdminPasswordText.setEnabled(false);
			
			checkDupAdminEmailBtn.setEnabled(false);
			
			availableAdminEmail = true;
		}

		addEventListener();
		
		return area;
	}

	private void addEventListener() {
		//
		checkDupCommNameBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent event) {
				// 
				String communityName = inputCommNameText.getText();
				if (communityName.length() > 0) {
					if (communityService.findCommunity(communityName) != null) {
						MessageDialog.openError(getParentShell(), "오류메시지", 
								"이미 존재하는 커뮤니티입니다. 다른 이름을 사용하세요.");
						availableCommunity = false;
						return;
					} else {
						MessageDialog.openInformation(getParentShell(), "정보메시지", 
								"사용가능한 커뮤니티입니다.");
						checkDupCommNameBtn.setEnabled(false);
						availableCommunity = true;
						return;
					}
				}
			}
		});
		inputCommNameText.addModifyListener(new ModifyListener() {
			@Override
			public void modifyText(ModifyEvent arg0) {
				// 
				availableCommunity = false;
				checkDupCommNameBtn.setEnabled(true);
			}
		});
		// 
		checkDupAdminEmailBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent event) {
				// 
				String adminEmail = inputAdminEmailText.getText();
				if (adminEmail.length() > 0) {
					if (townerService.findTowner(adminEmail) != null) {
						MessageDialog.openError(getParentShell(), "오류메시지", 
								"이미 존재하는 이메일입니다. 다른 이메일을 사용하세요.");
						availableAdminEmail = false;
						return;
					} else {
						MessageDialog.openInformation(getParentShell(), "정보메시지", 
								"사용가능한 이메일입니다.");
						checkDupAdminEmailBtn.setEnabled(false);
						availableAdminEmail = true;
						return;
					}
				}
			}
		});
		inputAdminEmailText.addModifyListener(new ModifyListener() {
			@Override
			public void modifyText(ModifyEvent arg0) {
				// 
				availableAdminEmail = false;
				checkDupAdminEmailBtn.setEnabled(true);
			}
		});
	}

	@Override
	protected void okPressed() {
		// 
		registeredCommunity = null;
		
		if (availableCommunity == false) {
			MessageDialog.openError(getParentShell(), "오류메시지", "커뮤니티명 중복체크를 해주세요.");
			return;
		}
		
		String communityName = inputCommNameText.getText();
		String description = inputCommDescText.getText();
		String adminName = inputAdminNameText.getText();
		String email = inputAdminEmailText.getText();
		String password = inputAdminPasswordText.getText();
		
		if (SessionManager.getInstance().isLogin()) {
			communityService.registCommunity(communityName, description, email);
		} else {

			if (availableAdminEmail == false) {
				MessageDialog.openError(getParentShell(), "오류메시지",  "이메일 중복체크를 해주세요.");
				return;
			}
			
			if (description.length() == 0 || adminName.length() == 0 || password.length() == 0) {
				MessageDialog.openError(getParentShell(), "오류메시지", "모든 정보를 빈칸없이 채워주세요.");
				return;
			}
			communityService.registCommunity(communityName, description, adminName, email, password);
			SessionManager.getInstance().login(email, password);
		}
		
		registeredCommunity = communityService.findCommunity(communityName);
		super.okPressed();
	}
	
	public Community getCommunity() {
		return registeredCommunity;
	}

	/**
	 * Create contents of the button bar.
	 * @param parent
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		//
		createButton(parent, IDialogConstants.OK_ID, "커뮤니티 개설", true);
		createButton(parent, IDialogConstants.CANCEL_ID, "취소", false);
	}

	/**
	 * Return the initial size of the dialog.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(450, 402);
	}
	
	@Override
	protected void configureShell(Shell newShell) {
		//
		super.configureShell(newShell);
		newShell.setText("커뮤니티 개설");
	}

}
