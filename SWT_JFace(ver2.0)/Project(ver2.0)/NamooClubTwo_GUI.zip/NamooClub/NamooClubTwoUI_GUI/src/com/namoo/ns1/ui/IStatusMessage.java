package com.namoo.ns1.ui;

public interface IStatusMessage {
	
	void setMessage(String message);
}
