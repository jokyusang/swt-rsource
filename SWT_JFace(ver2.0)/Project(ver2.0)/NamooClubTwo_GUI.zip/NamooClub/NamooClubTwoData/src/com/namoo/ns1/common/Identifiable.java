package com.namoo.ns1.common;

import java.io.Serializable;

public interface Identifiable extends Serializable {
	// 
	public String getOId(); 
}